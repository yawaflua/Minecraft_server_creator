import windows as tkwindow
# import modules

tkwindow.windows()
     


