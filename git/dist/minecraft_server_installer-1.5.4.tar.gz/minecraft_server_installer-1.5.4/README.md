Made by https://github.com/yaflay
This is create server on new version minecraft.
if u dont use Python 3, dont use this. urllib dont working in Python2
if u seek some bug, write me in Telegram: @YaFlay
if u dont have C:/ disk, dont use this Python code, this crashed the code
Version: 1.5.4!
for free using with write link for my github.com
if u dont want to write my link, send project in my Telegram: @bebra_YaFlay
if u want using my code, try import minecraft_server_installer as minecraft 
or from minecraft_server_installer import (def), minecraft